
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');

const token = '7699586878:AAHdVOxWsZN6coxq1FRvU03WDAZglPhuP7o';
const bot = new TelegramBot(token, { polling: true });

let data = JSON.parse(fs.readFileSync('./lazy_run_bot_data.json', 'utf8'));

bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const firstName = msg.from.first_name;

  bot.sendMessage(chatId, `Привет, ${firstName}! Выбери соревнование:`, {
    reply_markup: {
      keyboard: data.races.map(r => [r.name]),
      resize_keyboard: true,
      one_time_keyboard: true,
    },
  });
});

bot.on('message', (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;

  const race = data.races.find(r => r.name === text);
  if (race) {
    const participants = race.participants.length;
    const drivers = race.drivers.length;

    bot.sendMessage(chatId, `Соревнование: ${race.name}
Дата: ${race.date}

Участников: ${participants}
На машине: ${drivers}`, {
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Я участвую', callback_data: `participate_${race.id}` }],
          [{ text: 'Я на машине', callback_data: `drive_${race.id}` }],
        ]
      }
    });
  }
});

bot.on('callback_query', (query) => {
  const chatId = query.message.chat.id;
  const userId = query.from.id;
  const dataQuery = query.data;

  const [action, raceId] = dataQuery.split('_');
  const race = data.races.find(r => r.id === raceId);

  if (!race) return;

  const alreadyIn = race.participants.includes(userId);
  const alreadyDriver = race.drivers.includes(userId);

  if (action === 'participate') {
    if (!alreadyIn) race.participants.push(userId);
    fs.writeFileSync('./lazy_run_bot_data.json', JSON.stringify(data, null, 2));
    bot.sendMessage(chatId, 'Ты добавлен в список участников!');
  }

  if (action === 'drive') {
    if (!alreadyDriver) {
      if (!race.participants.includes(userId)) race.participants.push(userId);
      race.drivers.push(userId);
    }
    fs.writeFileSync('./lazy_run_bot_data.json', JSON.stringify(data, null, 2));
    bot.sendMessage(chatId, 'Ты добавлен как водитель!');
  }
});
